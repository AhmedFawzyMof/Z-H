---@type ChadrcConfig
local M = {}

M.ui = { theme = 'falcon' }
M.plugins = "custom.plugins"
M.mappings = require "custom.mappings"

return M
